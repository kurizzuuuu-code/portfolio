const ext = typeof browser !== "undefined" ? browser : chrome;
const actionApi = ext.action || ext.browserAction;

const DEFAULT_PORT = 17890;
const PORT_MIN = 17890;
const PORT_MAX = 17899;

const DEFAULT_SETTINGS = {
  port: DEFAULT_PORT,
  autoIntercept: true,
  interceptTorrents: true,
  focusApp: true,
  showVideoButton: true,
  videoButtonOpacity: 75,
  minSizeKB: 0,
  ignoredDomains: "",
};

const handlingIds = new Set();
const recentIntercepts = new Map();

function pruneRecentIntercepts(now = Date.now()) {
  for (const [key, ts] of recentIntercepts) {
    if (now - ts > 12000) recentIntercepts.delete(key);
  }
}

async function getSettings() {
  const stored = await ext.storage.local.get(Object.keys(DEFAULT_SETTINGS));
  return { ...DEFAULT_SETTINGS, ...stored };
}

async function setBrowserDownloadUi(enabled) {
  try {
    if (ext.downloads && typeof ext.downloads.setUiOptions === "function") {
      await ext.downloads.setUiOptions({ enabled });
    }
  } catch {}
}

async function updateBadge() {
  const { autoIntercept } = await getSettings();
  await setBrowserDownloadUi(!autoIntercept);
  try {
    if (!actionApi) return;
    if (autoIntercept) {
      await actionApi.setBadgeText({ text: "" });
    } else {
      await actionApi.setBadgeText({ text: "OFF" });
      await actionApi.setBadgeBackgroundColor({ color: "#6b7280" });
    }
  } catch {}
}

updateBadge();

async function pingPort(port, timeoutMs = 800) {
  try {
    const r = await fetch(`http://127.0.0.1:${port}/ping`, {
      signal: AbortSignal.timeout(timeoutMs),
    });
    if (r.ok) return await r.json();
  } catch {}
  return null;
}

async function findBridge() {
  for (let p = PORT_MIN; p <= PORT_MAX; p++) {
    const data = await pingPort(p, 600);
    if (data && data.ok) {
      await ext.storage.local.set({ port: p });
      return p;
    }
  }
  return null;
}

async function getCookiesHeader(url) {
  try {
    const cookies = await ext.cookies.getAll({ url });
    if (!cookies || cookies.length === 0) return undefined;
    return cookies.map((c) => `${c.name}=${c.value}`).join("; ");
  } catch {
    return undefined;
  }
}

async function getNetscapeCookies(url) {
  try {
    const list = [...(await ext.cookies.getAll({ url }))];
    try {
      const host = new URL(url).hostname.toLowerCase();
      if (host === "fb.watch" || host === "facebook.com" || host.endsWith(".facebook.com")) {
        const fb = await ext.cookies.getAll({ url: "https://www.facebook.com/" });
        list.push(...fb);
      }
    } catch {}
    if (list.length === 0) return undefined;

    const seen = new Set();
    const lines = ["# Netscape HTTP Cookie File"];
    for (const c of list) {
      const key = `${c.domain}|${c.path}|${c.name}`;
      if (seen.has(key)) continue;
      seen.add(key);
      const includeSub = c.hostOnly ? "FALSE" : "TRUE";
      const secure = c.secure ? "TRUE" : "FALSE";
      const expiry = c.expirationDate ? Math.floor(c.expirationDate) : 0;
      lines.push(`${c.domain}\t${includeSub}\t${c.path}\t${secure}\t${expiry}\t${c.name}\t${c.value}`);
    }
    return lines.join("\n");
  } catch {
    return undefined;
  }
}

async function tryAdd(port, payload) {
  try {
    const r = await fetch(`http://127.0.0.1:${port}/add`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(45000),
    });
    const data = await r.json().catch(() => null);
    if (r.ok && data && data.ok) return data;
    return { ok: false, error: (data && data.error) || `HTTP ${r.status}`, reachable: true };
  } catch {
    return { ok: false, error: "unreachable", reachable: false };
  }
}

async function sendToWisp({ url, referer, fileName, mime, rejectHtml = false, useYtdlp = false }) {
  if (!url) return { ok: false, error: "missing url" };

  const isMagnet = url.toLowerCase().startsWith("magnet:");
  if (!isMagnet && !/^https?:\/\//i.test(url)) {
    return { ok: false, error: "only http/https and magnet links are supported" };
  }

  const { port: savedPort, focusApp } = await getSettings();
  const cookies = isMagnet ? undefined : await getCookiesHeader(url);
  const cookies_netscape = isMagnet ? undefined : await getNetscapeCookies(url);
  const payload = {
    url,
    referer: referer || undefined,
    cookies,
    cookies_netscape,
    user_agent: navigator.userAgent,
    file_name: fileName || undefined,
    mime: mime || undefined,
    reject_html: rejectHtml,
    focus: focusApp !== false,
    use_ytdlp: Boolean(useYtdlp),
  };

  let res = await tryAdd(savedPort, payload);
  if (res.ok) return res;

  if (!res.reachable) {
    const found = await findBridge();
    if (found && found !== savedPort) {
      res = await tryAdd(found, payload);
    }
  }
  return res;
}

function notify(title, message) {
  try {
    ext.notifications.create({
      type: "basic",
      iconUrl: ext.runtime.getURL("icon.png"),
      title,
      message,
    });
  } catch {}
}

function isTorrentDownload(url, filename, mime) {
  const m = (mime || "").toLowerCase();
  if (m === "application/x-bittorrent") return true;
  const f = (filename || "").toLowerCase();
  if (f.endsWith(".torrent")) return true;
  try {
    const pathname = new URL(url).pathname.toLowerCase();
    if (pathname.endsWith(".torrent")) return true;
  } catch {}
  return false;
}

function isIgnoredDomain(url, ignoredDomainsStr) {
  if (!ignoredDomainsStr || !ignoredDomainsStr.trim()) return false;
  let host = "";
  try {
    host = new URL(url).hostname.toLowerCase();
  } catch {
    return false;
  }
  const domains = ignoredDomainsStr
    .split(/[,\n\s]+/)
    .map((d) => d.trim().toLowerCase())
    .filter(Boolean);
  return domains.some((d) => host === d || host.endsWith(`.${d}`));
}

function basename(p) {
  if (!p) return "";
  return p.split(/[\\/]/).pop() || "";
}

// --- Automatic Firefox Browser Download Interception ---
ext.downloads.onCreated.addListener((item) => {
  if (!item || handlingIds.has(item.id) || item.byExtensionId === ext.runtime.id) {
    return;
  }

  const url = item.finalUrl || item.url;
  if (!url || !/^https?:\/\//i.test(url)) {
    return;
  }

  const mime = (item.mime || "").toLowerCase();
  if (mime === "text/html" || mime === "application/xhtml+xml") {
    return;
  }

  handlingIds.add(item.id);
  interceptDownload(item, url).finally(() => {
    setTimeout(() => handlingIds.delete(item.id), 3000);
  });
});

async function interceptDownload(item, url) {
  let settled = false;
  try {
    await ext.downloads.pause(item.id);
  } catch {}

  const handBackToBrowser = async () => {
    if (settled) return;
    settled = true;
    await setBrowserDownloadUi(true);
    try {
      await ext.downloads.resume(item.id);
    } catch {}
    setTimeout(() => {
      getSettings().then((s) => {
        if (s.autoIntercept) setBrowserDownloadUi(false);
      });
    }, 2500);
  };

  const cancelBrowserDownload = async () => {
    if (settled) return;
    settled = true;
    try {
      await ext.downloads.cancel(item.id);
    } catch {}
    try {
      await ext.downloads.erase({ id: item.id });
    } catch {}
  };

  try {
    const settings = await getSettings();
    const torrent = isTorrentDownload(url, item.filename, item.mime);

    if (torrent) {
      if (!settings.interceptTorrents) {
        await handBackToBrowser();
        return;
      }
    } else {
      if (!settings.autoIntercept) {
        await handBackToBrowser();
        return;
      }
      if (
        settings.minSizeKB > 0 &&
        typeof item.fileSize === "number" &&
        item.fileSize > 0 &&
        item.fileSize < settings.minSizeKB * 1024
      ) {
        await handBackToBrowser();
        return;
      }
    }

    let activeTabUrl = "";
    try {
      const [tab] = await ext.tabs.query({ active: true, lastFocusedWindow: true });
      if (tab && tab.url) activeTabUrl = tab.url;
    } catch {}

    if (
      isIgnoredDomain(url, settings.ignoredDomains) ||
      (item.referrer && isIgnoredDomain(item.referrer, settings.ignoredDomains)) ||
      (activeTabUrl && isIgnoredDomain(activeTabUrl, settings.ignoredDomains))
    ) {
      await handBackToBrowser();
      return;
    }

    const now = Date.now();
    pruneRecentIntercepts(now);
    const fileBase = basename(item.filename);
    const urlKey = `u:${url}`;
    const fileKey =
      fileBase && typeof item.fileSize === "number" && item.fileSize > 0
        ? `f:${fileBase.toLowerCase()}|${item.fileSize}`
        : "";

    if (recentIntercepts.has(urlKey) || (fileKey && recentIntercepts.has(fileKey))) {
      await cancelBrowserDownload();
      return;
    }

    let port = settings.port;
    const alive = await pingPort(port, 400);
    if (!alive) {
      const found = await findBridge();
      if (!found) {
        await handBackToBrowser();
        return;
      }
      port = found;
    }

    recentIntercepts.set(urlKey, now);
    if (fileKey) recentIntercepts.set(fileKey, now);

    const res = await sendToWisp({
      url,
      referer: item.referrer || undefined,
      fileName: fileBase || undefined,
      mime: item.mime || undefined,
      rejectHtml: true,
    });

    if (res && res.ok) {
      await cancelBrowserDownload();
      notify("Wisp", `queued: ${res.file_name}`);
    } else {
      recentIntercepts.delete(urlKey);
      if (fileKey) recentIntercepts.delete(fileKey);
      await handBackToBrowser();
    }
  } catch {
    await handBackToBrowser();
  } finally {
    if (!settled) {
      await handBackToBrowser();
    }
  }
}

// --- Context Menus ---
async function setupMenus() {
  try {
    await ext.contextMenus.removeAll();
    ext.contextMenus.create({
      id: "wisp-download-link",
      title: "Download with Wisp",
      contexts: ["link"],
    });
    ext.contextMenus.create({
      id: "wisp-download-media",
      title: "Download media with Wisp",
      contexts: ["image", "video", "audio"],
    });
    ext.contextMenus.create({
      id: "wisp-download-page",
      title: "Download page / video with Wisp",
      contexts: ["page"],
    });
    ext.contextMenus.create({
      id: "wisp-download-selection",
      title: "Download selected link with Wisp",
      contexts: ["selection"],
    });
  } catch {}
}

ext.runtime.onInstalled.addListener(() => {
  setupMenus();
  updateBadge();
});

ext.runtime.onStartup.addListener(() => {
  setupMenus();
  updateBadge();
});

ext.storage.onChanged.addListener((changes) => {
  if (changes.autoIntercept) {
    updateBadge();
  }
});

ext.contextMenus.onClicked.addListener(async (info) => {
  let url = info.linkUrl || info.srcUrl;
  let useYtdlp = false;

  if (info.menuItemId === "wisp-download-media") {
    if (!url || url.startsWith("blob:") || url.startsWith("data:")) {
      url = info.pageUrl;
      useYtdlp = true;
    } else if (info.mediaType === "video" || info.mediaType === "audio") {
      if (!/\.(mp4|webm|mkv|mov|mp3|wav|ogg|m4a|png|jpe?g|webp|gif)(\?|$)/i.test(url)) {
        url = info.pageUrl || url;
        useYtdlp = true;
      }
    }
  } else if (info.menuItemId === "wisp-download-page") {
    url = info.pageUrl;
    useYtdlp = true;
  } else if (info.menuItemId === "wisp-download-selection") {
    const text = (info.selectionText || "").trim();
    const match = text.match(/(?:https?:\/\/|magnet:\?)[^\s"'<>]+/i);
    url = match ? match[0] : text;
  }
  if (!url) return;

  const res = await sendToWisp({
    url,
    referer: info.pageUrl || undefined,
    rejectHtml: false,
    useYtdlp,
  });

  if (res && res.ok) {
    notify("Wisp", `queued: ${res.file_name}`);
  } else {
    notify("Wisp", res && res.error ? res.error : "could not reach Wisp — is it running?");
  }
});

// --- Messages from Popup & Content Script ---
ext.runtime.onMessage.addListener((msg, sender) => {
  if (!msg) return undefined;

  if (msg.type === "getSiteConfig") {
    return getSettings().then((s) => {
      const tabUrl = (sender && sender.tab && sender.tab.url) || "";
      const blocked = tabUrl ? isIgnoredDomain(tabUrl, s.ignoredDomains) : false;
      return {
        showVideoButton: s.showVideoButton !== false,
        videoButtonOpacity: typeof s.videoButtonOpacity === "number" ? s.videoButtonOpacity : 75,
        interceptTorrents: s.interceptTorrents !== false,
        blocked,
      };
    });
  }

  if (msg.type === "add" && msg.url) {
    return sendToWisp({
      url: msg.url,
      referer: msg.referer || (sender && sender.tab && sender.tab.url) || undefined,
      fileName: msg.fileName || undefined,
      rejectHtml: Boolean(msg.rejectHtml),
      useYtdlp: Boolean(msg.useYtdlp),
    }).then((res) => {
      if (msg.notify) {
        if (res && res.ok) {
          notify("Wisp", `queued: ${res.file_name}`);
        } else {
          notify("Wisp", (res && res.error) || "could not reach Wisp — is it running?");
        }
      }
      return res || { ok: false };
    });
  }

  if (msg.type === "ping") {
    return getSettings().then(async ({ port }) => {
      const data = await pingPort(port, 1200);
      if (data && data.ok) return data;
      const found = await findBridge();
      return found ? { ok: true, port: found } : { ok: false };
    });
  }

  return undefined;
});
