const DEFAULT_PORT = 17890;
const PORT_MIN = 17890;
const PORT_MAX = 17899;

const DEFAULT_SETTINGS = {
  port: DEFAULT_PORT,
  autoIntercept: true,
  interceptTorrents: true,
  focusApp: true,
  showVideoButton: true,
  videoButtonOpacity: 75,
  minSizeKB: 0,
  ignoredDomains: "",
};

const handlingIds = new Set();
const recentIntercepts = new Map();

function pruneRecentIntercepts(now = Date.now()) {
  for (const [key, ts] of recentIntercepts) {
    if (now - ts > 12000) recentIntercepts.delete(key);
  }
}

async function getSettings() {
  const stored = await chrome.storage.local.get(Object.keys(DEFAULT_SETTINGS));
  return { ...DEFAULT_SETTINGS, ...stored };
}

async function setBrowserDownloadUi(enabled) {
  try {
    if (chrome.downloads && chrome.downloads.setUiOptions) {
      await chrome.downloads.setUiOptions({ enabled });
    }
  } catch {}
}

async function updateBadge() {
  const { autoIntercept } = await getSettings();
  await setBrowserDownloadUi(!autoIntercept);
  try {
    if (autoIntercept) {
      await chrome.action.setBadgeText({ text: "" });
    } else {
      await chrome.action.setBadgeText({ text: "OFF" });
      await chrome.action.setBadgeBackgroundColor({ color: "#6b7280" });
    }
  } catch {}
}

updateBadge();

async function pingPort(port, timeoutMs = 800) {
  try {
    const r = await fetch(`http://127.0.0.1:${port}/ping`, {
      signal: AbortSignal.timeout(timeoutMs),
    });
    if (r.ok) return await r.json();
  } catch {}
  return null;
}

async function findBridge() {
  for (let p = PORT_MIN; p <= PORT_MAX; p++) {
    const data = await pingPort(p, 600);
    if (data && data.ok) {
      await chrome.storage.local.set({ port: p });
      return p;
    }
  }
  return null;
}

async function getCookiesHeader(url) {
  try {
    const cookies = await chrome.cookies.getAll({ url });
    if (!cookies || cookies.length === 0) return undefined;
    return cookies.map((c) => `${c.name}=${c.value}`).join("; ");
  } catch {
    return undefined;
  }
}

async function getNetscapeCookies(url) {
  try {
    const list = [...(await chrome.cookies.getAll({ url }))];
    try {
      const host = new URL(url).hostname.toLowerCase();
      if (host === "fb.watch" || host === "facebook.com" || host.endsWith(".facebook.com")) {
        const fb = await chrome.cookies.getAll({ url: "https://www.facebook.com/" });
        list.push(...fb);
      }
    } catch {}
    if (list.length === 0) return undefined;

    const seen = new Set();
    const lines = ["# Netscape HTTP Cookie File"];
    for (const c of list) {
      const key = `${c.domain}|${c.path}|${c.name}`;
      if (seen.has(key)) continue;
      seen.add(key);
      const includeSub = c.hostOnly ? "FALSE" : "TRUE";
      const secure = c.secure ? "TRUE" : "FALSE";
      const expiry = c.expirationDate ? Math.floor(c.expirationDate) : 0;
      lines.push(`${c.domain}\t${includeSub}\t${c.path}\t${secure}\t${expiry}\t${c.name}\t${c.value}`);
    }
    return lines.join("\n");
  } catch {
    return undefined;
  }
}

async function tryAdd(port, payload) {
  try {
    const r = await fetch(`http://127.0.0.1:${port}/add`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(45000),
    });
    const data = await r.json().catch(() => null);
    if (r.ok && data && data.ok) return data;
    return { ok: false, error: (data && data.error) || `HTTP ${r.status}`, reachable: true };
  } catch {
    return { ok: false, error: "unreachable", reachable: false };
  }
}

async function sendToWisp({ url, referer, fileName, mime, rejectHtml = false, useYtdlp = false }) {
  if (!url) return { ok: false, error: "missing url" };

  const isMagnet = url.toLowerCase().startsWith("magnet:");
  if (!isMagnet && !/^https?:\/\//i.test(url)) {
    return { ok: false, error: "only http/https and magnet links are supported" };
  }

  const { port: savedPort, focusApp } = await getSettings();
  const cookies = isMagnet ? undefined : await getCookiesHeader(url);
  const cookies_netscape = isMagnet ? undefined : await getNetscapeCookies(url);
  const payload = {
    url,
    referer: referer || undefined,
    cookies,
    cookies_netscape,
    user_agent: navigator.userAgent,
    file_name: fileName || undefined,
    mime: mime || undefined,
    reject_html: rejectHtml,
    focus: focusApp !== false,
    use_ytdlp: Boolean(useYtdlp),
  };

  let res = await tryAdd(savedPort, payload);
  if (res.ok) return res;

  // If the saved port wasn't reachable, scan the bridge port range once.
  if (!res.reachable) {
    const found = await findBridge();
    if (found && found !== savedPort) {
      res = await tryAdd(found, payload);
    }
  }
  return res;
}

function notify(title, message) {
  try {
    chrome.notifications.create({
      type: "basic",
      iconUrl: "icon.png",
      title,
      message,
    });
  } catch {}
}

function isTorrentDownload(url, filename, mime) {
  const m = (mime || "").toLowerCase();
  if (m === "application/x-bittorrent") return true;
  const f = (filename || "").toLowerCase();
  if (f.endsWith(".torrent")) return true;
  try {
    const pathname = new URL(url).pathname.toLowerCase();
    if (pathname.endsWith(".torrent")) return true;
  } catch {}
  return false;
}

function isIgnoredDomain(url, ignoredDomainsStr) {
  if (!ignoredDomainsStr || !ignoredDomainsStr.trim()) return false;
  let host = "";
  try {
    host = new URL(url).hostname.toLowerCase();
  } catch {
    return false;
  }
  const domains = ignoredDomainsStr
    .split(/[,\n\s]+/)
    .map((d) => d.trim().toLowerCase())
    .filter(Boolean);
  return domains.some((d) => host === d || host.endsWith(`.${d}`));
}

function basename(path) {
  if (!path) return "";
  return path.split(/[\\/]/).pop() || "";
}

// --- Automatic Browser Download Interception ---
chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  if (handlingIds.has(item.id) || item.byExtensionId === chrome.runtime.id) {
    setBrowserDownloadUi(true);
    suggest();
    return;
  }

  const url = item.finalUrl || item.url;
  if (!url || !/^https?:\/\//i.test(url)) {
    setBrowserDownloadUi(true);
    suggest();
    return;
  }

  // Skip HTML pages (Save Page As, CAPTCHA/bot-check redirects).
  const mime = (item.mime || "").toLowerCase();
  if (mime === "text/html" || mime === "application/xhtml+xml") {
    setBrowserDownloadUi(true);
    suggest();
    return;
  }

  handlingIds.add(item.id);
  interceptDownload(item, url, suggest).finally(() => {
    setTimeout(() => handlingIds.delete(item.id), 3000);
  });
  // Return true so Chrome holds the download before showing Save As or starting bytes.
  return true;
});

async function interceptDownload(item, url, suggest) {
  let settled = false;
  const handBackToBrowser = async () => {
    if (settled) return;
    settled = true;
    await setBrowserDownloadUi(true);
    try {
      suggest();
    } catch {}
    setTimeout(() => {
      getSettings().then((s) => {
        if (s.autoIntercept) setBrowserDownloadUi(false);
      });
    }, 2500);
  };
  const cancelBrowserDownload = async () => {
    if (settled) return;
    settled = true;
    try {
      await chrome.downloads.cancel(item.id);
    } catch {}
    try {
      await chrome.downloads.erase({ id: item.id });
    } catch {}
    try {
      suggest();
    } catch {}
  };

  try {
    const settings = await getSettings();
    const torrent = isTorrentDownload(url, item.filename, item.mime);

    if (torrent) {
      if (!settings.interceptTorrents) {
        await handBackToBrowser();
        return;
      }
    } else {
      if (!settings.autoIntercept) {
        await handBackToBrowser();
        return;
      }
      if (
        settings.minSizeKB > 0 &&
        typeof item.fileSize === "number" &&
        item.fileSize > 0 &&
        item.fileSize < settings.minSizeKB * 1024
      ) {
        await handBackToBrowser();
        return;
      }
    }

    // Check both the download URL's domain and the referring/active page's domain
    // so blocking e.g. "github.com" also blocks its CDN downloads.
    let activeTabUrl = "";
    try {
      const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (tab && tab.url) activeTabUrl = tab.url;
    } catch {}

    if (
      isIgnoredDomain(url, settings.ignoredDomains) ||
      (item.referrer && isIgnoredDomain(item.referrer, settings.ignoredDomains)) ||
      (activeTabUrl && isIgnoredDomain(activeTabUrl, settings.ignoredDomains))
    ) {
      await handBackToBrowser();
      return;
    }

    // Deduplicate sites (like itch.io) that trigger two parallel download events
    // for the same file within a few seconds.
    const now = Date.now();
    pruneRecentIntercepts(now);
    const fileBase = basename(item.filename);
    const urlKey = `u:${url}`;
    const fileKey =
      fileBase && typeof item.fileSize === "number" && item.fileSize > 0
        ? `f:${fileBase.toLowerCase()}|${item.fileSize}`
        : "";

    if (recentIntercepts.has(urlKey) || (fileKey && recentIntercepts.has(fileKey))) {
      await cancelBrowserDownload();
      return;
    }

    // Quick reachability check before handing off to Wisp.
    let port = settings.port;
    let alive = await pingPort(port, 400);
    if (!alive) {
      const found = await findBridge();
      if (!found) {
        // Wisp isn't running — let browser download normally.
        await handBackToBrowser();
        return;
      }
      port = found;
    }

    recentIntercepts.set(urlKey, now);
    if (fileKey) recentIntercepts.set(fileKey, now);

    const res = await sendToWisp({
      url,
      referer: item.referrer || undefined,
      fileName: fileBase || undefined,
      mime: item.mime || undefined,
      rejectHtml: true,
    });

    if (res && res.ok) {
      await cancelBrowserDownload();
      notify("Wisp", `queued: ${res.file_name}`);
    } else {
      recentIntercepts.delete(urlKey);
      if (fileKey) recentIntercepts.delete(fileKey);
      // Hand back to browser cleanly (e.g. CAPTCHA/login page or unsupported server).
      await handBackToBrowser();
    }
  } catch {
    await handBackToBrowser();
  } finally {
    if (!settled) {
      await handBackToBrowser();
    }
  }
}

// --- Context Menus ---
function setupMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "wisp-download-link",
      title: "Download with Wisp",
      contexts: ["link"],
    });
    chrome.contextMenus.create({
      id: "wisp-download-media",
      title: "Download media with Wisp",
      contexts: ["image", "video", "audio"],
    });
    chrome.contextMenus.create({
      id: "wisp-download-page",
      title: "Download page / video with Wisp",
      contexts: ["page"],
    });
    chrome.contextMenus.create({
      id: "wisp-download-selection",
      title: "Download selected link with Wisp",
      contexts: ["selection"],
    });
  });
}

chrome.runtime.onInstalled.addListener(() => {
  setupMenus();
  updateBadge();
});

chrome.runtime.onStartup.addListener(() => {
  updateBadge();
});

chrome.storage.onChanged.addListener((changes) => {
  if (changes.autoIntercept) {
    updateBadge();
  }
});

chrome.contextMenus.onClicked.addListener(async (info) => {
  let url = info.linkUrl || info.srcUrl;
  let useYtdlp = false;

  if (info.menuItemId === "wisp-download-media") {
    if (!url || url.startsWith("blob:") || url.startsWith("data:")) {
      url = info.pageUrl;
      useYtdlp = true;
    } else if (info.mediaType === "video" || info.mediaType === "audio") {
      // On YouTube/FB/etc., <video src> may be a blob or MSE stream; if pageUrl is a
      // media page, prefer yt-dlp on pageUrl when src isn't a plain file.
      if (!/\.(mp4|webm|mkv|mov|mp3|wav|ogg|m4a|png|jpe?g|webp|gif)(\?|$)/i.test(url)) {
        url = info.pageUrl || url;
        useYtdlp = true;
      }
    }
  } else if (info.menuItemId === "wisp-download-page") {
    url = info.pageUrl;
    useYtdlp = true;
  } else if (info.menuItemId === "wisp-download-selection") {
    const text = (info.selectionText || "").trim();
    const match = text.match(/(?:https?:\/\/|magnet:\?)[^\s"'<>]+/i);
    url = match ? match[0] : text;
  }
  if (!url) return;

  const res = await sendToWisp({
    url,
    referer: info.pageUrl || undefined,
    rejectHtml: false,
    useYtdlp,
  });

  if (res && res.ok) {
    notify("Wisp", `queued: ${res.file_name}`);
  } else {
    notify("Wisp", res && res.error ? res.error : "could not reach Wisp — is it running?");
  }
});

// --- Messages from Popup & Content Script ---
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;

  if (msg.type === "getSiteConfig") {
    getSettings().then((s) => {
      const tabUrl = (sender.tab && sender.tab.url) || "";
      const blocked = tabUrl ? isIgnoredDomain(tabUrl, s.ignoredDomains) : false;
      sendResponse({
        showVideoButton: s.showVideoButton !== false,
        videoButtonOpacity: typeof s.videoButtonOpacity === "number" ? s.videoButtonOpacity : 75,
        interceptTorrents: s.interceptTorrents !== false,
        blocked,
      });
    });
    return true;
  }

  if (msg.type === "add" && msg.url) {
    sendToWisp({
      url: msg.url,
      referer: msg.referer || (sender.tab && sender.tab.url) || undefined,
      fileName: msg.fileName || undefined,
      rejectHtml: Boolean(msg.rejectHtml),
      useYtdlp: Boolean(msg.useYtdlp),
    }).then((res) => {
      if (msg.notify) {
        if (res && res.ok) {
          notify("Wisp", `queued: ${res.file_name}`);
        } else {
          notify("Wisp", (res && res.error) || "could not reach Wisp — is it running?");
        }
      }
      sendResponse(res || { ok: false });
    });
    return true;
  }

  if (msg.type === "ping") {
    getSettings().then(async ({ port }) => {
      const data = await pingPort(port, 1200);
      if (data && data.ok) {
        sendResponse(data);
        return;
      }
      const found = await findBridge();
      sendResponse(found ? { ok: true, port: found } : { ok: false });
    });
    return true;
  }
});
