// Wisp content script:
// 1. Intercepts magnet: link clicks (when torrent capture is enabled & site is allowed).
// 2. Alt+Click any http(s) or magnet: link to force-send it straight to Wisp.
// 3. Places a compact, opacity-adjustable download icon button over HTML5 <video> players
//    (YouTube, Facebook, TikTok, Instagram, X, Reddit, Vimeo, Twitch, and general sites).

(() => {
  let siteConfig = {
    showVideoButton: true,
    videoButtonOpacity: 75,
    interceptTorrents: true,
    blocked: false,
  };

  function refreshConfig() {
    try {
      chrome.runtime.sendMessage({ type: "getSiteConfig" }, (cfg) => {
        if (chrome.runtime.lastError || !cfg) return;
        siteConfig = cfg;
        scheduleScan();
      });
    } catch {}
  }

  refreshConfig();
  try {
    chrome.storage.onChanged.addListener(() => {
      refreshConfig();
    });
  } catch {}

  // --- Link Click Handling (magnet: + Alt+Click) ---
  document.addEventListener(
    "click",
    (event) => {
      if (event.button !== 0) return;
      const anchor = event.target && event.target.closest ? event.target.closest("a[href]") : null;
      if (!anchor) return;

      const href = anchor.href;
      if (!href) return;

      if (href.toLowerCase().startsWith("magnet:")) {
        if (siteConfig.interceptTorrents && !siteConfig.blocked) {
          event.preventDefault();
          event.stopPropagation();
          chrome.runtime.sendMessage({
            type: "add",
            url: href,
            referer: window.location.href,
            notify: true,
          });
        }
        return;
      }

      if (event.altKey && /^https?:\/\//i.test(href)) {
        event.preventDefault();
        event.stopPropagation();
        chrome.runtime.sendMessage({
          type: "add",
          url: href,
          referer: window.location.href,
          notify: true,
        });
      }
    },
    true
  );

  // --- Floating Video Download Icon Button ---
  const YTDLP_HOST_RE =
    /(^|\.)(youtube\.com|youtu\.be|facebook\.com|fb\.watch|tiktok\.com|instagram\.com|x\.com|twitter\.com|reddit\.com|redd\.it|vimeo\.com|twitch\.tv|dailymotion\.com|bilibili\.com|rumble\.com)$/i;

  const ICON_DOWNLOAD =
    '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11"/><path d="m7 11 5 5 5-5"/><path d="M5 20h14"/></svg>';
  const ICON_SPIN =
    '<svg class="wisp-spin" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>';
  const ICON_CHECK =
    '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12.5 4.5 4.5L19 7"/></svg>';
  const ICON_ALERT =
    '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 8v5"/><circle cx="12" cy="17" r="1" fill="currentColor" stroke="none"/></svg>';

  let overlayHost = null;
  let shadowRoot = null;
  const videoButtons = new Map(); // video element -> button element
  let scanQueued = false;

  function ensureOverlay() {
    if (shadowRoot) return shadowRoot;
    overlayHost = document.createElement("div");
    overlayHost.id = "wisp-video-overlay-root";
    overlayHost.style.cssText =
      "position:fixed;inset:0;pointer-events:none;z-index:2147483640;margin:0;padding:0;border:0;";
    shadowRoot = overlayHost.attachShadow({ mode: "open" });

    const style = document.createElement("style");
    style.textContent = `
      .wisp-vid-btn {
        position: fixed;
        pointer-events: auto;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        padding: 0;
        border: 2px solid #2a1a3a;
        border-radius: 8px;
        background: #7c3aed;
        color: #ffffff;
        cursor: pointer;
        box-shadow: 2px 2px 0 #2a1a3a;
        opacity: var(--wisp-btn-opacity, 0.75);
        transition: opacity 0.15s ease, transform 0.12s ease, background 0.15s ease;
        user-select: none;
      }
      .wisp-vid-btn:hover {
        opacity: 1 !important;
        background: #6d28d9;
      }
      .wisp-vid-btn:active {
        transform: translate(1px, 1px);
        box-shadow: 1px 1px 0 #2a1a3a;
      }
      .wisp-vid-btn.is-ok {
        background: #16a34a;
        opacity: 1 !important;
      }
      .wisp-vid-btn.is-bad {
        background: #dc2626;
        opacity: 1 !important;
      }
      .wisp-spin {
        animation: wisp-spin 0.9s linear infinite;
      }
      @keyframes wisp-spin {
        to { transform: rotate(360deg); }
      }
    `;
    shadowRoot.appendChild(style);
    (document.documentElement || document.body).appendChild(overlayHost);
    return shadowRoot;
  }

  function clearAllButtons() {
    for (const btn of videoButtons.values()) {
      btn.remove();
    }
    videoButtons.clear();
  }

  function resolveVideoTarget(video) {
    const host = window.location.hostname.toLowerCase();
    const pageUrl = window.location.href;
    const src = video.currentSrc || video.src || "";
    const isDirectFile =
      /^https?:\/\//i.test(src) &&
      !/\.(m3u8|mpd)(\?|$)/i.test(src) &&
      !YTDLP_HOST_RE.test(host);

    if (isDirectFile) {
      return { url: src, useYtdlp: false };
    }

    // YouTube watch/shorts pages already have the exact video URL in the address bar.
    if (/(^|\.)(youtube\.com|youtu\.be)$/i.test(host)) {
      if (/\/watch.*[?&]v=|\/shorts\//i.test(pageUrl) || host === "youtu.be") {
        return { url: pageUrl, useYtdlp: true };
      }
    }

    // Facebook: use current URL when already on a specific video/reel/watch?v= page,
    // otherwise locate the post's specific video permalink (ignoring bare /watch/ tab links).
    if (host === "fb.watch" || /(^|\.)facebook\.com$/i.test(host)) {
      if (
        host === "fb.watch" ||
        /\/reel\/\d+|\/videos\/\d+|\/watch\/?\?[^#]*v=\d+|\/share\/[vr]\/|story_fbid=/i.test(pageUrl)
      ) {
        return { url: pageUrl, useYtdlp: true };
      }
      const fbBox = video.closest(
        '[role="article"], [data-pagelet*="FeedUnit"], [data-pagelet*="Watch"], [role="dialog"]'
      );
      if (fbBox) {
        const links = Array.from(fbBox.querySelectorAll("a[href]"));
        const match = links.find((a) =>
          /\/reel\/\d+|\/videos\/\d+|\/watch\/?\?[^#]*v=\d+|\/share\/[vr]\/|story_fbid=|\/posts\/|\/permalink\//i.test(
            a.href
          )
        );
        if (match && /^https?:\/\//i.test(match.href)) {
          return { url: match.href, useYtdlp: true };
        }
      }
      return { url: pageUrl, useYtdlp: true };
    }

    const container = video.closest(
      'article, [role="article"], ytd-rich-item-renderer, ytd-video-renderer, ytd-reel-video-renderer, shreddit-post'
    );
    if (container) {
      const permalink = container.querySelector(
        'a[href*="/watch"], a[href*="/shorts/"], a[href*="/videos/"], a[href*="/reel"], a[href*="/status/"], a[href*="/video/"], a[href*="/comments/"]'
      );
      if (permalink && permalink.href && /^https?:\/\//i.test(permalink.href)) {
        return { url: permalink.href, useYtdlp: true };
      }
    }

    return { url: pageUrl, useYtdlp: true };
  }

  function createButtonForVideo(video) {
    const root = ensureOverlay();
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "wisp-vid-btn";
    btn.title = "Download with Wisp";
    btn.setAttribute("aria-label", "Download with Wisp");
    btn.innerHTML = ICON_DOWNLOAD;

    const stop = (e) => {
      e.preventDefault();
      e.stopPropagation();
    };
    btn.addEventListener("mousedown", stop, true);
    btn.addEventListener("pointerdown", stop, true);
    btn.addEventListener(
      "click",
      (e) => {
        e.preventDefault();
        e.stopPropagation();
        const target = resolveVideoTarget(video);
        btn.classList.remove("is-ok", "is-bad");
        btn.title = "Sending to Wisp…";
        btn.innerHTML = ICON_SPIN;
        chrome.runtime.sendMessage(
          {
            type: "add",
            url: target.url,
            referer: window.location.href,
            useYtdlp: target.useYtdlp,
            notify: true,
          },
          (res) => {
            if (res && res.ok) {
              btn.classList.add("is-ok");
              btn.title = `Queued: ${res.file_name || "video"}`;
              btn.innerHTML = ICON_CHECK;
              setTimeout(() => {
                btn.classList.remove("is-ok");
                btn.title = "Download with Wisp";
                btn.innerHTML = ICON_DOWNLOAD;
              }, 2000);
            } else {
              btn.classList.add("is-bad");
              btn.title = (res && res.error) || "Wisp not reachable";
              btn.innerHTML = ICON_ALERT;
              setTimeout(() => {
                btn.classList.remove("is-bad");
                btn.title = "Download with Wisp";
                btn.innerHTML = ICON_DOWNLOAD;
              }, 3000);
            }
          }
        );
      },
      true
    );

    root.appendChild(btn);
    return btn;
  }

  function isPreviewOrInvalidVideo(video, rect, host) {
    if (
      video.closest(
        '[aria-hidden="true"], [data-testid*="preview" i], [class*="thumbnail" i], [class*="storyboard" i], [id*="preview" i]'
      )
    ) {
      return true;
    }

    if (/(^|\.)youtube\.com$/i.test(host)) {
      if (
        video.closest(
          "ytd-video-preview, #inline-preview-player, #video-preview-container, ytd-moving-thumbnail-renderer, ytd-thumbnail, .ytp-tooltip, .ytp-storyboard, .ytp-ce-element, .ytp-autonav-endscreen-upnext-thumbnail"
        )
      ) {
        return true;
      }
      const inRealPlayer = video.closest(
        "#movie_player, #shorts-player, ytd-reel-video-renderer, #ytd-player"
      );
      if (!inRealPlayer || inRealPlayer.closest("#inline-preview-player")) {
        return true;
      }
    } else {
      if (video.readyState === 0 && !video.currentSrc && !video.src) {
        return true;
      }
      const minW = video.controls ? 180 : 220;
      const minH = video.controls ? 100 : 125;
      if (rect.width < minW || rect.height < minH) {
        return true;
      }
    }

    if (!video.controls && video.loop && video.muted && rect.width < 300) {
      return true;
    }

    return false;
  }

  function updateButtons() {
    scanQueued = false;
    if (!siteConfig.showVideoButton || siteConfig.blocked) {
      clearAllButtons();
      return;
    }

    const host = window.location.hostname.toLowerCase();
    const opacityVal = Math.max(0.1, Math.min(1, (siteConfig.videoButtonOpacity ?? 75) / 100));
    const videos = Array.from(document.querySelectorAll("video"));
    const activeSet = new Set();
    const vw = window.innerWidth;
    const vh = window.innerHeight;

    for (const video of videos) {
      const rect = video.getBoundingClientRect();
      const visible =
        rect.width >= 180 &&
        rect.height >= 100 &&
        rect.bottom > 20 &&
        rect.top < vh - 20 &&
        rect.right > 20 &&
        rect.left < vw - 20;

      if (!visible) continue;
      if (isPreviewOrInvalidVideo(video, rect, host)) continue;

      const style = window.getComputedStyle(video);
      if (style.display === "none" || style.visibility === "hidden" || style.opacity === "0") {
        continue;
      }

      activeSet.add(video);
      let btn = videoButtons.get(video);
      if (!btn) {
        btn = createButtonForVideo(video);
        videoButtons.set(video, btn);
      }

      btn.style.setProperty("--wisp-btn-opacity", String(opacityVal));
      const btnW = btn.offsetWidth || 32;
      const top = Math.max(8, Math.min(vh - 40, rect.top + 10));
      const left = Math.max(8, Math.min(vw - btnW - 8, rect.right - btnW - 10));
      btn.style.top = `${Math.round(top)}px`;
      btn.style.left = `${Math.round(left)}px`;
    }

    for (const [video, btn] of videoButtons) {
      if (!activeSet.has(video) || !document.contains(video)) {
        btn.remove();
        videoButtons.delete(video);
      }
    }
  }

  function scheduleScan() {
    if (scanQueued) return;
    scanQueued = true;
    requestAnimationFrame(updateButtons);
  }

  window.addEventListener("scroll", scheduleScan, { passive: true, capture: true });
  window.addEventListener("resize", scheduleScan, { passive: true });
  document.addEventListener("fullscreenchange", scheduleScan);

  const observer = new MutationObserver(() => scheduleScan());
  if (document.documentElement) {
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }
  window.setInterval(scheduleScan, 1500);
})();
