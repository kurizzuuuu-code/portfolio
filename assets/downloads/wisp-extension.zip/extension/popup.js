const statusEl = document.getElementById("status");
const actionMsgEl = document.getElementById("action-msg");
const portEl = document.getElementById("port");
const autoInterceptEl = document.getElementById("autoIntercept");
const interceptTorrentsEl = document.getElementById("interceptTorrents");
const focusAppEl = document.getElementById("focusApp");
const showVideoButtonEl = document.getElementById("showVideoButton");
const videoButtonOpacityEl = document.getElementById("videoButtonOpacity");
const videoOpacityValEl = document.getElementById("videoOpacityVal");
const minSizeKBEl = document.getElementById("minSizeKB");
const ignoredDomainsEl = document.getElementById("ignoredDomains");

const siteCardEl = document.getElementById("site-card");
const siteHostEl = document.getElementById("site-host");
const sitePillEl = document.getElementById("site-pill");
const toggleSiteBtn = document.getElementById("toggle-site");

const DEFAULTS = {
  port: 17890,
  autoIntercept: true,
  interceptTorrents: true,
  focusApp: true,
  showVideoButton: true,
  videoButtonOpacity: 75,
  minSizeKB: 0,
  ignoredDomains: "",
};

let currentHost = "";

function parseDomains(str) {
  return (str || "")
    .split(/[,\n\s]+/)
    .map((d) => d.trim().toLowerCase())
    .filter(Boolean);
}

function isHostBlocked(host, domains) {
  return domains.some((d) => host === d || host.endsWith(`.${d}`));
}

function renderSiteCard() {
  if (!currentHost) {
    siteCardEl.style.display = "none";
    return;
  }
  siteCardEl.style.display = "block";
  siteHostEl.textContent = currentHost;
  const blocked = isHostBlocked(currentHost, parseDomains(ignoredDomainsEl.value));
  if (blocked) {
    sitePillEl.textContent = "Not allowed";
    sitePillEl.className = "pill blocked";
    toggleSiteBtn.textContent = "Allow downloads on this site";
    toggleSiteBtn.className = "full allow";
  } else {
    sitePillEl.textContent = "Allowed";
    sitePillEl.className = "pill allowed";
    toggleSiteBtn.textContent = "Don't allow on this site";
    toggleSiteBtn.className = "full danger";
  }
}

async function detectCurrentSite() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url && /^https?:\/\//i.test(tab.url)) {
      currentHost = new URL(tab.url).hostname.toLowerCase();
    }
  } catch {}
  renderSiteCard();
}

async function loadSettings() {
  const data = { ...DEFAULTS, ...(await chrome.storage.local.get(Object.keys(DEFAULTS))) };
  portEl.value = data.port;
  autoInterceptEl.checked = Boolean(data.autoIntercept);
  interceptTorrentsEl.checked = Boolean(data.interceptTorrents);
  focusAppEl.checked = data.focusApp !== false;
  showVideoButtonEl.checked = data.showVideoButton !== false;
  const opacity = typeof data.videoButtonOpacity === "number" ? data.videoButtonOpacity : 75;
  videoButtonOpacityEl.value = opacity;
  videoOpacityValEl.textContent = `${opacity}%`;
  minSizeKBEl.value = Number(data.minSizeKB) || 0;
  ignoredDomainsEl.value = data.ignoredDomains || "";
}

async function saveSettings(showMsg = true) {
  const next = {
    port: Math.min(17899, Math.max(17890, Number(portEl.value) || 17890)),
    autoIntercept: autoInterceptEl.checked,
    interceptTorrents: interceptTorrentsEl.checked,
    focusApp: focusAppEl.checked,
    showVideoButton: showVideoButtonEl.checked,
    videoButtonOpacity: Math.min(100, Math.max(10, Number(videoButtonOpacityEl.value) || 75)),
    minSizeKB: Math.max(0, Number(minSizeKBEl.value) || 0),
    ignoredDomains: ignoredDomainsEl.value.trim(),
  };
  await chrome.storage.local.set(next);
  renderSiteCard();
  if (showMsg) {
    actionMsgEl.textContent = "saved!";
    actionMsgEl.className = "ok";
    setTimeout(() => {
      if (actionMsgEl.textContent === "saved!") actionMsgEl.textContent = "";
    }, 1500);
  }
}

function checkBridge() {
  statusEl.textContent = "checking…";
  statusEl.className = "";
  chrome.runtime.sendMessage({ type: "ping" }, (res) => {
    if (res && res.ok) {
      statusEl.textContent = `connected on port ${res.port || portEl.value}`;
      statusEl.className = "ok";
      if (res.port) {
        portEl.value = res.port;
        chrome.storage.local.set({ port: res.port });
      }
    } else {
      statusEl.textContent = "wisp not reachable — start the app";
      statusEl.className = "bad";
    }
  });
}

toggleSiteBtn.addEventListener("click", async () => {
  if (!currentHost) return;
  const domains = parseDomains(ignoredDomainsEl.value);
  let nextDomains;
  if (isHostBlocked(currentHost, domains)) {
    // Remove exact host or parent domain entries that match currentHost
    nextDomains = domains.filter((d) => !(currentHost === d || currentHost.endsWith(`.${d}`)));
  } else {
    nextDomains = [...new Set([...domains, currentHost])];
  }
  ignoredDomainsEl.value = nextDomains.join(", ");
  await saveSettings(false);
});

autoInterceptEl.addEventListener("change", () => saveSettings(false));
interceptTorrentsEl.addEventListener("change", () => saveSettings(false));
focusAppEl.addEventListener("change", () => saveSettings(false));
showVideoButtonEl.addEventListener("change", () => saveSettings(false));
videoButtonOpacityEl.addEventListener("input", () => {
  videoOpacityValEl.textContent = `${videoButtonOpacityEl.value}%`;
  saveSettings(false);
});
ignoredDomainsEl.addEventListener("input", renderSiteCard);

document.getElementById("save").addEventListener("click", async () => {
  await saveSettings(true);
  checkBridge();
});

document.getElementById("scan").addEventListener("click", () => {
  statusEl.textContent = "scanning…";
  checkBridge();
});

document.getElementById("grab-tab").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url || !/^https?:\/\//i.test(tab.url)) {
    actionMsgEl.textContent = "active tab is not an http(s) link";
    actionMsgEl.className = "bad";
    return;
  }
  actionMsgEl.textContent = "sending to Wisp…";
  actionMsgEl.className = "";
  chrome.runtime.sendMessage(
    { type: "add", url: tab.url, referer: tab.url, notify: false },
    (res) => {
      if (res && res.ok) {
        actionMsgEl.textContent = `queued: ${res.file_name}`;
        actionMsgEl.className = "ok";
      } else {
        actionMsgEl.textContent = (res && res.error) || "could not reach Wisp";
        actionMsgEl.className = "bad";
      }
    }
  );
});

loadSettings().then(() => {
  detectCurrentSite();
  checkBridge();
});
